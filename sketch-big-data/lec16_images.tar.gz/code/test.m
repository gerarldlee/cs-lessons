x1 = [-1,5];
x1 = x1/norm(x1);
y1 = [1,10];
y1 = y1/norm(y1);

x2 = [-1,5];
x2 = x2/norm(x2);
y2 = [1,-1];
y2 = y2/norm(y2);

figure(); hold on
subplot(1,2,1);
ang=0:0.01:2*pi; 
xp=cos(ang);
yp=sin(ang);
plot(xp,yp,'k'); hold on
quiver(0,0,x1(1),x1(2),0); hold on
quiver(0,0,y1(1),y1(2),0); hold on
quiver(0,0,x1(1)+y1(1),x1(2)+y1(2),0); hold on
quiver(0,0,x1(1)-y1(1),x1(2)-y1(2),0); hold on
axis([-1.2 1.2 -1.2 2]);
subplot(1,2,2);
plot(xp,yp,'k'); hold on
quiver(0,0,x2(1),x2(2),0); hold on
quiver(0,0,y2(1),y2(2),0); hold on
quiver(0,0,x2(1)+y2(1),x2(2)+y2(2),0); hold on
quiver(0,0,x2(1)-y2(1),x2(2)-y2(2),0); hold on
axis([-1.2 1.2 -1.2 2]);
