A = imread('piotr.jpg');
Y = fft2(A);
M = max(max(max(abs(Y))));
indices = find(abs(Y)<M*0.0005);
Y(indices) = 0;
X = abs(ifft2(Y));
X = uint8(X);

figure(); hold on
subplot(2,2,1);
imagesc(A);
subplot(2,2,2);
imagesc(X);

A = imread('jelani.jpg');
Y = fft2(A);
M = max(max(max(abs(Y))));
indices = find(abs(Y)<M*0.0001);
Y(indices) = 0;
X = abs(ifft2(Y));
X = uint8(X);

subplot(2,2,3);
imagesc(A);
subplot(2,2,4);
imagesc(X);
