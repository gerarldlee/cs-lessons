n = 64;
omega = exp(2i*pi/n);

F = zeros(n,n);
Finv = zeros(n,n);

for i = 1:n
    for j = 1:n
        F(i,j) = omega^(-(i-1)*(j-1))/n;
        Finv(i,j) = omega^((i-1)*(j-1));
    end
end

ahat = zeros(n,1);
ahat(2) = 1;
a = Finv*ahat;

bhat = zeros(n,1);
bhat(3) = 1;
b = Finv*bhat;

chat = zeros(n,1);
chat(10) = 1;
c = Finv*chat;

dhat = zeros(n,1);
dhat(11) = 1;
d = Finv*dhat;

figure(); hold on
subplot(2,2,1);
plot(0:n-1,real(a)); hold on
plot(n/2,real(a(n/2+1)),'r*');
axis([0 n-1 -1 1]);
subplot(2,2,2);
plot(0:n-1,real(b)); hold on
plot(n/2,real(b(n/2+1)),'r*');
axis([0 n-1 -1 1]);
subplot(2,2,3);
plot(0:n-1,real(c)); hold on
plot(n/2,real(c(n/2+1)),'r*');
axis([0 n-1 -1 1]);
subplot(2,2,4);
plot(0:n-1,real(d)); hold on
plot(n/2,real(d(n/2+1)),'r*');
axis([0 n-1 -1 1]);